public class DiaryEntry {
    private String name;
    private String contents;
    private Category[] categories;
    private Account accounts;

}
