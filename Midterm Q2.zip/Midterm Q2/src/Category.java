public class Category {

    private String name;
}
