public class Account {

    private String name;
    private Category category;

}
